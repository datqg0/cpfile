//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

class Node {
	public:
	int data;
	int index;
	Node* left;
	Node* right;
};

void inorder (Node *root) {
	if(root==NULL) {
		
	}
	else {
	
	inorder(root->left);
	cout<< root->data<<" ";
	inorder(root->right);
	
	}
}

void buildheap (Node * point,vector<int>&nums) {
	int index=point->index;
	int a=2*index+1;
	int b=2*index+2;
	Node* lefty=new Node();
	Node* righty=new Node();
	
	if(a<nums.size()) {
		lefty->data=nums[a];
		lefty->index=a;
		point->left=lefty;
		buildheap(lefty,nums);
	}
	else {
		point->left=NULL;
	}
	
	if(b<nums.size()) {
		righty->data=nums[b];
		righty->index=b;
		point->right=righty;
		buildheap(righty,nums);
	}
	else {
		point->right=NULL;
	}
}

void heapify (Node*point) {
	if(point->left!=NULL) {
		heapify(point->left);
	}
	if(point->right!=NULL) {
		heapify(point->right);
	}
	
	if(point->left==NULL&&point->right==NULL) {
		
	}
	else if(point->right==NULL) {
		if((point->left->data)>(point->data)) {
			int temp=point->data;
			point->data=point->left->data;
			point->left->data=temp;
		}
	}
	else if(point->left==NULL) {
		if((point->right->data)>(point->data)) {
			int temp=point->data;
			point->data=point->right->data;
			point->right->data=temp;
		}		
	}
	else {
		int a=point->data;
		int b=point->left->data;
		point->data=max(a,b);
		point->left->data=min(a,b);
		a=point->data;
		b=point->right->data;
		point->data=max(a,b);
		point->right->data=min(a,b);
		a=point->left->data;
		b=point->right->data;
		point->left->data=max(a,b);
		point->right->data=min(a,b);
		}
	if(point->left!=NULL) {
		heapify(point->left);
	}
	if(point->right!=NULL) {
		heapify(point->right);
	}
}
Node* findleaf(Node*point) {
	if()
}
void takeandremove (Node * point,vector<int>&out ) {
	
}

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	int n;
	cin>>n;
	vector<int> nums(n);
	for(int i=0;i<n;i++) {
		cin>>nums[i];
	}
	vector<int> out;
	Node*root=new Node();
	root->data=nums[0];
	root->index=0;
	buildheap(root,nums);
	inorder(root);
	cout<<endl;
	heapify(root);
	inorder(root);
}
