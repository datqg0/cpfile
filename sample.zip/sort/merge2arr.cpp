//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

vector<int> merge (vector<int> l,vector<int> r ) {
	
	vector<int> out;
	int a=l.size();
	int b=r.size();
	int i=0;
	int j=0;
	
	while(i<a&&j<b) {
		if(l[i]<r[j]) {
			out.push_back(l[i]);
			i++;
		}
		else if(r[j]<l[i]) {
			out.push_back(r[j]);
			j++;
		}
		else {
			out.push_back(l[i]);
			out.push_back(r[j]);
			i++;
			j++;
		}
	}
	
	while(j<b) {
		out.push_back(r[j]);
		j++;
	}
	
	while(i<a) {
		out.push_back(l[i]);
		i++;
	}
	
	return out;
}

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	int n;
	cin>>n;
	int m;
	cin>>m;
	vector<int> nums1(n);
	vector<int> nums2(m);
	
	for(int i=0;i<n;i++) {
		cin>>nums1[i];
	}
	for(int i=0;i<m;i++) {
		cin>>nums2[i];
	}
	
	vector<int> out=merge(nums1,nums2);
	
	for(int i=0;i<out.size();i++) {
		cout<<out[i]<<" ";
	}
	cout<<endl;
}
