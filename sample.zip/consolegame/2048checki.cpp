//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

void printy (vector<vector<int> >&sto) {
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			cout<<sto[i][j]<<" ";
		}
		cout<<endl;
	}
}

int main() {
    bool check=false;
  	vector<int> temp(4,0);
	vector<vector<int> > sto(4,temp);
	vector<bool> temp2(4,false);
	vector< vector<bool> > merge(4,temp2);
	
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			cin>>sto[i][j];
		}
	}
	int move;
	cin>>move;
	int k,know;
    //move
	if(move==0) {
		for(int i=0;i<4;i++) {
			for(int j=0;j<4;j++) {
				 if(sto[i][j]!=0) {
				 	k=j-1;
				 	know=j;
				 	while(k>=0) {
                         check=true;
				 		if(sto[i][k]==0) {
				 			sto[i][k]=sto[i][know];
				 			sto[i][know]=0;
				 			know=k;
				 			k--;
				 		}
				 		else if(sto[i][k]!=sto[i][know]) {
				 				break;
				 		}
				 		else {
				 			if(merge[i][k]==false) {
                                check=true;
				 				sto[i][k]=sto[i][know]*2;
				 				sto[i][know]=0;
				 				merge[i][k]=true;
				 			}
				 			break;
				 		}
				 	}
				 }
			}
		}
	}
	else if(move==1) {
		for(int j=0;j<4;j++) {
			for(int i=0;i<4;i++) {
				if(sto[i][j]!=0) {
					k=i-1;
					while(k>=0) {
						if(sto[k][j]==0) {
                            check=true;
				 			sto[k][j]=sto[k+1][j];
				 			sto[k+1][j]=0;
				 		}
				 		else if(sto[k][j]!=sto[k+1][j] ) {
				 				break;
				 		}
				 		else {
				 			if(merge[k][j]==false) {
                                check=true;
				 				sto[k][j]=sto[k+1][j]*2;
				 				sto[k+1][j]=0;
				 				merge[k][j]=true;
				 			}
				 			break;
				 		}
				 		k--;
					}
				}
			}
		}
	}
	else if(move==2) {
		for(int i=0;i<4;i++) {
			for(int j=3;j>=0;j--) {
				if(sto[i][j]!=0) {
					k=j+1;
					know=j;
					while(k<=3) {
						if(sto[i][k]==0){
                            check=true;
							sto[i][k]=sto[i][know];
							sto[i][know]=0;
							know=k;
							k++;
						}
						else if(sto[i][k]!=sto[i][know]||merge[k][j]==true) {
							break;
						}
						else {
							if(merge[i][k]==false) {
                                check=true;
								sto[i][k]=sto[i][know]*2;
				 				sto[i][know]=0;
				 				merge[i][k]=true;
							}
							break;
						}
					} 
				}
			}
		}
	}
	else {
		for(int j=0;j<4;j++) {
			for(int i=3;i>=0;i--) {
				if(sto[i][j]!=0) {
					k=i+1;
					while(k<=3) {
						if(sto[k][j]==0) {
                            check=true;
				 			sto[k][j]=sto[k-1][j];
				 			sto[k-1][j]=0;
				 		}
				 		else if(sto[k][j]!=sto[k-1][j] ) {
				 				break;
				 		}
				 		else {
				 			if(merge[k][j]==false) {
                                check=true;
				 				sto[k][j]=sto[k-1][j]*2;
				 				sto[k-1][j]=0;
				 				merge[k][j]=true;
				 			}
				 			break;
				 		}
				 		k++;
					}
				}
			}
		}
	}
    printy(sto);
	
}
