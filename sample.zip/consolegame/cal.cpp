//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

long long cal (string& s,long long l,long long r,vector<long long>&match) {
        long long k=l;
        long long out=0;
        long long ope=-1;
        while(k<=r&&k<s.size()) {
            if(s[k]==' ') {
                k++;
            }
            else if(s[k]=='+') {
                ope=1;
                k++;
            }
            else if(s[k]=='-') {
               	if(ope==2) {
               		ope=1;
               	}
               	else {
               		ope=2;
               	}
               	k++;
            }
            else if((s[k]-'0')>=0 && (s[k]-'0')<=9) {
                string number="";
                while((s[k]-'0')>=0 && (s[k]-'0')<=9&&k<=s.size()) {
                    number+=s[k];
                    k++;
                }
                long long l=0;
                long long m=1;
                for(long long i=number.size()-1;i>=0;i--) {
                    long long x=number[i]-48;
                    l+=m*x;
                    m*=10;
                }
                if(ope==-1) {
                    out=l;
                }
                else if (ope==1) {
                    out+=l;
                }
                else {
                    out-=l;
                }
                ope=-1;
            }
            else if(s[k]=='(') {
            	if(ope==-1) {
            		out=cal(s,k+1,match[k]-1,match);
            	}
            	else if(ope==1) {
                	out+=cal(s,k+1,match[k]-1,match);
                }
                else {
                	out-=cal(s,k+1,match[k]-1,match);
                }
                ope =-1;
                k=match[k]+1;
            }
            else if(s[k]==')') {
            	k++;
            }
            else {
                k++;
            }
        }

        return out;
    }
    long long calculate(string s) {
        vector<long long> match (s.size(),-1);
        stack<long long> bracketpair;
        for(long long i=0;i<s.size();i++) {
            if(s[i]=='(') {
                bracketpair.push(i);
            }
            else if(s[i]==')') {
                long long take=bracketpair.top();
                match[take]=i;
                bracketpair.pop();
            }
        }
        return cal (s,0,s.size()-1,match);
    }

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	string s;
	getline(cin,s);
	cout<< calculate(s);
}
