//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

class fraction {
	public: 
	int numerator;
	int denominator;
	
	//
	fraction operator+(const fraction & ob) {
		return 
	}
}

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	
}
