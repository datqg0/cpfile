//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	priority_queue<int,vector<int>,greater<int> > m;
	m.push(1);
	m.push(9);
	m.push(3);
	m.push(5);
	
	while(m.empty()!=true) {
		cout<<m.top()<<" ";
		m.pop();
	}
	cout<<endl;
	//Methods
	/* 	.size()
		.empty()
		.top()
		.pop()
		.push()
		.swap()(*swap two queue)
		.emplace()
		*/
	//operator overloading it use to custom the priority of priority queue 
	// it not only > of = or < it can be anything 
	
		
}
