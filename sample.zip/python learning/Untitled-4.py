n,d,h=map(int,input().split())
sto=[];
for i in map(int,input().split()):
	sto.append(i)

print(sto)
print(*sto,sep=(","))
u=0;
if u==1 :
	print("YES");
else :
	print("NO"); 