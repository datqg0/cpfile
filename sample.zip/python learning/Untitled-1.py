#python element

a=6
b="higg"
c=[4,5,6,7,7]

#for i in c:
	#print (i,end=" ")
#print (c)
#print (*c)

#for i in range(len(c)):
	#print(i,c[i])

#for i in range (5) :
	#print(i)

#i=0
#while i<9:
#	print(i,end=" ")
#	i+=1

row=5
column=6;
sto=[[0]*column]*row
print (sto)
sto2=[[]]

o=[0,9,8]
sto2.append(o)
print (sto2)

sto3=[[0 for i in range (3)] for j in range (3)]
print (sto3)

print(1/3)