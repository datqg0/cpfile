//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

int main() {
	ios::sync_with_stdio(false);
  	cin.tie(0);
	vector<ll> power (33,1);
	ll j=1;
	
	for(ll i=1;i<=32;i++) {
		power[i]=j*2;
		j=j*2;
	}
	
	for(ll i=0;i<=32;i++) {
		cout<<power[i]<<endl;
	}
}
