//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

int change (int* a) {
	*a=1;
	return *a;
}

int main() {
	int a=5;
	change(&a);
	int b=6;
	change(&b);
	cout<<a<<endl;
	cout<<b<<endl;
}
