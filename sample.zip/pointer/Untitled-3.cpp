//???
#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

void modify (int * a[100]) {
	for(int i=0;i<100;i++) {
		*a[i]=1000;
	} 
}

/*void display (vector<int>*a) {
	for(int i=0;i<*a.size();i++) {
		//cout<<*a[i]<<" ";
	}
	cout<<endl;
}*/
int main() {
	int a[100];
	int b[100];
	modify(&a);
	//display(&a);
	modify(&b);
	//display(&b);
}
