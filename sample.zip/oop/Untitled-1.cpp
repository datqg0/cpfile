#include<bits/stdc++.h>

class Human {
public:
    std::string Name;
    int Age;
    std::string Personal;
    std::vector<std::string> strong;
    void display() {
        std::cout<<Name<<std::endl;
        std::cout<<Age<<std::endl;
        std::cout<<Personal<<std::endl;
        for (int i=0;i<strong.size();i++) {
            std::cout<<strong[i]<<" ";
        }
        std::cout<<std::endl;
    }
};

int main() {
    Human Dat;
    Dat.Name="Nguyen Huu Dat";
    Dat.Age=19;
    Dat.Personal="UNDEFINE";
    Dat.strong={"sleep","sing"};
    Dat.display();
}